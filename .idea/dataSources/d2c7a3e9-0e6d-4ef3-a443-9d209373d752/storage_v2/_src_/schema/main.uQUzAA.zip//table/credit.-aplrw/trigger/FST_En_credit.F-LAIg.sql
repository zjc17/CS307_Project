CREATE TRIGGER FST_En_credit AFTER INSERT ON credit
  BEGIN
    INSERT INTO English_FTS (id,name,table_type) VALUES (new.id,new.name,'C');
  end;

