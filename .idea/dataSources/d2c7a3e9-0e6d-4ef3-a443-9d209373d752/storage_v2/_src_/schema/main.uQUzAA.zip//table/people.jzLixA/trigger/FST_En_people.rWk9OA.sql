CREATE TRIGGER FST_En_people AFTER INSERT ON people
  BEGIN
    INSERT INTO English_FTS (id,name,table_type) VALUES (new.id,new.name,'P');
  end;

