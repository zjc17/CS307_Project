CREATE TRIGGER FST_En_song AFTER INSERT ON song
  BEGIN
    INSERT INTO English_FTS (id,name,table_type) VALUES (new.id,new.name,'S');
  end;

