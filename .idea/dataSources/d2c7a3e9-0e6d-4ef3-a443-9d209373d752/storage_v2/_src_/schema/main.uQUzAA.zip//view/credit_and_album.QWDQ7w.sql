CREATE VIEW credit_and_album as
select pac.credit_id, pac.people_id,pac.name as people_name,
       pac.picture_id as picture_id_people,
       a.id as album_id, a.name as album_name,
       a.picture_id as picture_id_album, track_total_number, compilation
from people_and_credit as pac
            left join credit_with_album cwa on cwa.credit_id = pac.credit_id
            left join album a on cwa.album_id = a.id;

