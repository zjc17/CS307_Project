CREATE TRIGGER FST_En_album AFTER INSERT ON album
  BEGIN
    INSERT INTO English_FTS (id,name,table_type) VALUES (new.id,new.name,'A');
  end;

