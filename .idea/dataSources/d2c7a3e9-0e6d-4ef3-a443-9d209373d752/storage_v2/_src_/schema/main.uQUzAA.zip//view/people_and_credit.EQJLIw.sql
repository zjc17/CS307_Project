CREATE VIEW people_and_credit as
select credit.id as credit_id, credit.people_id as people_id, people.name, people.name_for_sort, people.picture_id, credit_as
from credit join people  on credit.people_id = people.id;

