CREATE VIEW "artist" AS
SELECT credit.id AS id, people.name AS name, credit.name_for_sort AS name_for_sort, people.picture_id AS picture_id
FROM people
       INNER JOIN credit ON people.id = credit.people_id
WHERE credit_as = 'A';

