CREATE VIEW credit_song as
select pac.*, cws.song_id as song_id
from people_and_credit pac join credit_with_song cws on pac.credit_id = cws.credit_id;

